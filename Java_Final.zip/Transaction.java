import java.util.Date;

public class Transaction {
    private int transactionID;
    private Date date;
    private double amount;
    private String transactionType;
    private String accountNumber;

    public Transaction(int transactionID, Date date, double amount, String transactionType, String accountNumber) {
        this.transactionID = transactionID;
        this.date = date;
        this.amount = amount;
        this.transactionType = transactionType;
        this.accountNumber = accountNumber;
    }
}
