public class Account {
    private String accountNumber;
    private double balance;
    private AccountHolder accountHolder;
    private AccountType accountType;

    public Account(String accountNumber, double initialBalance, AccountHolder accountHolder, AccountType accountType) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
        this.accountHolder = accountHolder;
        this.accountType = accountType;
    }

    // Getter and setter methods for accountNumber
    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    // Getter and setter methods for balance
    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    // Getter and setter methods for accountHolder
    public AccountHolder getAccountHolder() {
        return accountHolder;
    }

    public void setAccountHolder(AccountHolder accountHolder) {
        this.accountHolder = accountHolder;
    }

    // Getter and setter methods for accountType
    public AccountType getAccountType() {
        return accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    // Methods for deposits, withdrawals, transfers, and statement generation
    public void deposit(double amount) {
        // Add the amount to the balance
        balance += amount;
    }

    public void withdraw(double amount) {
        // Check if the withdrawal amount is within the available balance
        if (amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Insufficient balance for withdrawal.");
        }
    }

    public void transfer(Account destinationAccount, double amount) {
        // Check if the transfer amount is within the available balance
        if (amount <= balance) {
            // Deduct the amount from this account
            balance -= amount;
            // Add the amount to the destination account
            destinationAccount.deposit(amount);
        } else {
            System.out.println("Insufficient balance for transfer.");
        }
    }

    public void generateAccountStatement() {
        // Generate and display the account statement
    }
}
