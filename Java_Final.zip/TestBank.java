public class TestBank {
    public static void main(String[] args) {
        // Create a bank and test account creation
        Bank bank = new Bank("MyBank");
        AccountHolder accountHolder = new AccountHolder("Jane Smith", "456 Elm St", "jane@example.com");
        bank.createAccount("9876543210", 2000.0, accountHolder, AccountType.CHECKING);

        // Test getting account information
        Account account = bank.getAccountInformation("9876543210");
        System.out.println("Account Holder: " + account.getAccountHolder().getName());
        System.out.println("Account Balance: " + account.getBalance());
    }
}
