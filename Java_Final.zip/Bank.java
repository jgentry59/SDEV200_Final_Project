import java.util.HashMap;
import java.util.Map;

public class Bank {
    private String bankName;
    private Map<String, Account> accounts;

    public Bank(String bankName) {
        this.bankName = bankName;
        this.accounts = new HashMap<>();
    }

    public void createAccount(String accountNumber, double initialBalance, AccountHolder accountHolder, AccountType accountType) {
        // Create a new account and add it to the accounts map
        Account newAccount = new Account(accountNumber, initialBalance, accountHolder, accountType);
        accounts.put(accountNumber, newAccount);
    }

    public Account getAccountInformation(String accountNumber) {
        // Retrieve and return the account information
        return accounts.get(accountNumber);
    }
}
