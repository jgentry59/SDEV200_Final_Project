public class TestAccount {
    public static void main(String[] args) {
        // Create an account
        AccountHolder accountHolder = new AccountHolder("John Doe", "123 Main St", "john@example.com");
        Bank bank = new Bank("MyBank");
        bank.createAccount("1234567890", 1000.0, accountHolder, AccountType.SAVINGS);

        // Perform transactions and test methods
        Account account = bank.getAccountInformation("1234567890");
        account.deposit(500.0);
        account.withdraw(200.0);
        account.generateAccountStatement();
    }
}
