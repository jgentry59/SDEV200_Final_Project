public class AccountHolder {
    private String name;
    private String address;
    private String contactInfo;

    public AccountHolder(String name, String address, String contactInfo) {
        this.name = name;
        this.address = address;
        this.contactInfo = contactInfo;
    }
    public String getName() {
        return name;
    }
}
